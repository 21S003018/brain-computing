# -*- coding: utf-8 -*-
"""

"""
import os
import globalvar as gl

class LTM():
    def __init__(self):
        self.address = None
        self.gist = None
        self.weight = None
        self.intensity = None
        self.mood = None
        return


class TIRED(LTM):
    def __init__(self, initFeeling=10):
        LTM.__init__(self)
        self.feeling = "tired"
        gl.set_value(self.feeling, initFeeling)
        return

    """
#    checkState方法
#    仅仅考虑这个feeling随时间因素的变化
    """

    def checkState(self):
        """
        暂且认为一分钟消耗0.015
        """
        delta = 0.015

        def content():
            gl.set_value(self.feeling, gl.get_value(self.feeling) - delta)
            return

        def periodicExec(func, inc=5):
            import time, sched
            s = sched.scheduler(time.time, time.sleep)

            def perform(inc):
                s.enter(inc, 0, perform, (inc,))
                func()

            s.enter(0, 0, perform, (inc,))
            s.run()
            return

        from threading import Thread
        state_update_thread = Thread(target=periodicExec, args=(content,))
        state_update_thread.setDaemon(True)
        state_update_thread.start()
        return


class HUNGRY(LTM):
    def __init__(self,initFeeling = 10):
        LTM.__init__(self)
        self.feeling = 'hungry'
        gl.set_value(self.feeling,initFeeling)
    """
#    checkState方法
#    仅仅考虑这个feeling随时间因素的变化
    """
    def checkState(self):
        """
        暂且认为一分钟消耗0.55
        """
        delta = 0.015
        def content():
            gl.set_value(self.feeling,gl.get_value(self.feeling) - delta)
            return
        def periodicExec(func,inc = 5):
            import time,sched
            s = sched.scheduler(time.time,time.sleep)
            def perform(inc):
                s.enter(inc,0,perform,(inc,))
                func()
            s.enter(0,0,perform,(inc,))
            s.run()
            return
        from threading import Thread
        state_update_thread = Thread(target = periodicExec,args = (content,))
        state_update_thread.setDaemon(True)
        state_update_thread.start()
        return
    """
#    getNeedIntensity方法
#    根据自身的状态返回需求强度
#    返回值是一个元组
    """
    def getNeedIntensity(self):
        needOfHungry = 10 / gl.get_value(self.feeling)
        return (needOfHungry,self.feeling)


class PAIN(LTM):
    def __init__(self,initFeeling = 10):
        LTM.__init__(self)
        self.feeling = 'pain'
        gl.set_value(self.feeling,initFeeling)
    """
#    checkState方法
#    仅仅考虑这个feeling随时间因素的变化
    """
    def checkState(self):
        """
        暂且认为一分钟消耗0.015
        """
        delta = 0.015
        def content():
            gl.set_value(self.feeling,gl.get_value(self.feeling) - delta)
            return
        def periodicExec(func,inc = 5):
            import time,sched
            s = sched.scheduler(time.time,time.sleep)
            def perform(inc):
                s.enter(inc,0,perform,(inc,))
                func()
            s.enter(0,0,perform,(inc,))
            s.run()
            return
        from threading import Thread
        state_update_thread = Thread(target = periodicExec,args = (content,))
        state_update_thread.setDaemon(True)
        state_update_thread.start()
        return
    """
#    getNeedIntensity方法
#    根据自身的状态返回需求强度
#    返回值是一个元组
    """
    def getNeedIntensity(self):
        need = 10 / gl.get_value(self.feeling)
        return (need,self.feeling)


class THIRSTY(LTM):
    def __init__(self,initFeeling = 10):
        LTM.__init__(self)
        self.feeling = 'thirsty'
        gl.set_value(self.feeling,initFeeling)
    """
#    checkState方法
#    仅仅考虑这个feeling随时间因素的变化
    """
    def checkState(self):
        """
        暂且认为一分钟消耗0.015
        """
        delta = 0.015
        def content():
            gl.set_value(self.feeling,gl.get_value(self.feeling) - delta)
            return
        def periodicExec(func,inc = 5):
            import time,sched
            s = sched.scheduler(time.time,time.sleep)
            def perform(inc):
                s.enter(inc,0,perform,(inc,))
                func()
            s.enter(0,0,perform,(inc,))
            s.run()
            return
        from threading import Thread
        state_update_thread = Thread(target = periodicExec,args = (content,))
        state_update_thread.setDaemon(True)
        state_update_thread.start()
        return
    """
#    getNeedIntensity方法
#    根据自身的状态返回需求强度
#    返回值是一个元组
    """
    def getNeedIntensity(self):
        need = 10 / gl.get_value(self.feeling)
        return (need,self.feeling)


class SEXY(LTM):
    def __init__(self,initFeeling = 10):
        LTM.__init__(self)
        self.feeling = 'sexy'
        gl.set_value(self.feeling,initFeeling)
    """
#    checkState方法
#    仅仅考虑这个feeling随时间因素的变化
    """
    def checkState(self):
        """
        暂且认为一分钟消耗0.015
        """
        delta = 0.015
        def content():
            gl.set_value(self.feeling,gl.get_value(self.feeling) - delta)
            return
        def periodicExec(func,inc = 5):
            import time,sched
            s = sched.scheduler(time.time,time.sleep)
            def perform(inc):
                s.enter(inc,0,perform,(inc,))
                func()
            s.enter(0,0,perform,(inc,))
            s.run()
            return
        from threading import Thread
        state_update_thread = Thread(target = periodicExec,args = (content,))
        state_update_thread.setDaemon(True)
        state_update_thread.start()
        return
    """
#    getNeedIntensity方法
#    根据自身的状态返回需求强度
#    返回值是一个元组
    """
    def getNeedIntensity(self):
        need = 10 / gl.get_value(self.feeling)
        return (need,self.feeling)


class OPTICALSENSOR():
    def __init__(self):
        return
    def collectMessage(self):
        def content():
            while True:
                '''检测环境反馈信息是否更新'''
                timeStamp = os.stat(gl.get_value('environmentMessagePath')).st_mtime
                while timeStamp == os.stat(gl.get_value('environmentMessagePath')).st_mtime:
                    import time
                    time.sleep(1)
                '''检测到环境信息文件更新，就进行信息的提取和整合'''
                '''shortTimeKnowledge中维护100个知识'''
                file = open(gl.get_value('environmentMessagePath'),'r')
                import json
                visionMessage = json.load(file)['vision']
                file.close()
                file = open(gl.get_value('shortTimeKnowledgePath'),'r')
                shortTimeMessage = json.load(file)
                file.close()
                newshortTimeMessage = {}
                i = 1
                for i in range(1,101):
                    if visionMessage.__contain__(i):
                        newshortTimeMessage[i] = visionMessage[i]
                    else:
                        break
                id = 1
                for x in range(i,101):
                    if shortTimeMessage.__contains__(id):
                        newshortTimeMessage[x] = shortTimeMessage[id]
                        id = id + 1
                    else:
                        break
                file = open(gl.get_value('shortTimeKnowledgePath'),'w')
                dic = json.dumps(newshortTimeMessage)
                file.write(str(dic))
                file.close()
        from threading import Thread
        problem_detect_thread = Thread(target = content)
        problem_detect_thread.setDaemon(True)
        problem_detect_thread.start()
        return


class SOUNDSENSOR():
    def __init__(self):
        return
    def collectMessage(self):
        def content():
            while True:
                '''检测文件是否更新'''
                timeStamp = os.stat(gl.get_value('environmentMessagePath')).st_mtime
                while timeStamp == os.stat(gl.get_value('environmentMessagePath')).st_mtime:
                    import time
                    time.sleep(1)
                '''检测到环境信息文件更新，就进行信息的提取和整合'''
                '''shortTimeKnowledge中维护100个知识'''
                file = open(gl.get_value('environmentMessagePath'),'r')
                import json
                visionMessage = json.load(file)['hearing']
                file.close()
                file = open(gl.get_value('shortTimeKnowledgePath'),'r')
                shortTimeMessage = json.load(file)
                file.close()
                newshortTimeMessage = {}
                i = 1
                for i in range(1,101):
                    if visionMessage.__contain__(i):
                        newshortTimeMessage[i] = visionMessage[i]
                    else:
                        break
                id = 1
                for x in range(i,101):
                    if shortTimeMessage.__contains__(id):
                        newshortTimeMessage[x] = shortTimeMessage[id]
                        id = id + 1
                    else:
                        break
                file = open(gl.get_value('shortTimeKnowledgePath'),'w')
                dic = json.dumps(newshortTimeMessage)
                file.write(str(dic))
                file.close()
        from threading import Thread
        problem_detect_thread = Thread(target = content)
        problem_detect_thread.setDaemon(True)
        problem_detect_thread.start()
        return
