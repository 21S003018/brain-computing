import globalvar as gl
from globalvar import *
import time
from ltm import *
from weightedKG import *
import time
from queue import Queue
from SPARQLWrapper import SPARQLWrapper, JSON
'''
交互文件路径
'''
class STM():
    def __init__(self, name):
        self.name = name # 配置姓名
        gl.configpath(name) # 配置文件路径
        self.kg = KnowldgeGraph(name) # 配置知识库以及知识图
        # 配置状态向量
        self.states = []
        self.states.append('tired')
        self.states.append('hungry')
        self.states.append('thirsty')
        self.states.append('pain')
        self.states.append('sexy')
        # 配置ltm
        self.eye = OPTICALSENSOR()
        self.ear = SOUNDSENSOR()
        self.tired = TIRED()
        self.hungry = HUNGRY()
        self.thirsty = THIRSTY()
        self.pain = PAIN()
        self.sexy = SEXY()
        self.ltms = [self.tired,self.hungry,self.thirsty,self.pain,self.sexy]
        # 配置uptree和downtree
        self.updowntree = UpDownTree(self.ltms)
        # 配置正在解决的需求
        self.tempsolving = set()
        return

    """
#    detectLife方法
#    检测声明是否存在
    """
    def detectLife(self):
        def content():
            while True:
                die = False
                ans = {}
                ans['tired'] = gl.get_value('tired')
                ans['hungry'] = gl.get_value('hungry')
                ans['thirsty'] = gl.get_value('thirsty')
                ans['pain'] = gl.get_value('pain')
                ans['sexy'] = gl.get_value('sexy')
                if gl.get_value('tired') < 0:
                    die = True
                if gl.get_value('hungry') < 0:
                    die = True
                if gl.get_value('thirsty') < 0:
                    die = True
                if gl.get_value('pain') < 0:
                    die = True
                if gl.get_value('sexy') < 0:
                    die = True
                if die == True:
                    import os
                    cmd = "taskkill /F /PID " + str(os.getpid())
                    os.system(cmd)
                import time
                time.sleep(1)
                print(self.name)
                print(ans)

        from threading import Thread
        state_update_thread = Thread(target=content)
        state_update_thread.setDaemon(True)
        state_update_thread.start()

    """
#    start方法
#    内部开始感知自己的状态
#    外部开始收集信息
#    stm开始检测需求，检测声明是否存在
    """
    def start(self):
        # ltm开始运行
        self.tired.checkState()
        self.hungry.checkState()
        self.thirsty.checkState()
        self.pain.checkState()
        self.sexy.checkState()
        self.eye.collectMessage()
        self.ear.collectMessage()
        # 判断死亡
        self.detectLife()
        # 基于需求的决策生成与实施过程
        self.loop()
        return

    """
#     loop方法
    """
    def loop(self):
        while True:
            self.updowntree.uptree(self.updowntree.root)
            time.sleep(SLEEPTIME)
            # 获取需求
            tempneed = self.updowntree.root.gist
            if self.tempsolving.__contains__(tempneed):
                continue
            if len(self.tempsolving) > 0:
                continue
            if self.updowntree.root.weight > 5:
                continue
            if self.updowntree.root.gist == None:
                continue
            method = self.decide(tempneed)
            eval(str(method))
        return
    '''
    '''
    def decide(self,need):
        # 搜索能解决当前问题的方法
        methods = self.kg.querymethod(need)
        # 通过模拟计算出最好的方法
        bestMethod = None
        maxReward = 0
        for x in methods:
            self.kg.setFactor1(x,1)
            tmpReward = self.kg.calReward('happy')
            print('method')
            print(x)
            print('tmpReward')
            print(tmpReward)
            if maxReward < tmpReward:
                bestMethod = x
                maxReward = tmpReward
        return bestMethod

    # def think(self):
    #     """
    # #    think方法
    # #    slots有空位置的时候就进行思考
    # #    两个版本,一个是基于知识图谱的搜索推理完成的，当然也可以通过强化学习完成
    #     """
    #     def content():
    #         return
    #
    #     from threading import Thread
    #     problem_detect_thread = Thread(target=content)
    #     problem_detect_thread.setDaemon(True)
    #     problem_detect_thread.start()
    #     return




SLEEPTIME = 1
class Trunk():
    def __init__(self,address,gist,weight,intensity,mood):
        self.address = address
        self.gist = gist
        self.weight = weight
        self.intensity = intensity
        self.mood = mood
        self.LeftChild = None
        self.RightChild = None
    def set(self,address,gist,weight,intensity,mood):
        self.address = address
        self.gist = gist
        self.weight = weight
        self.intensity = intensity
        self.mood = mood
class UpDownTree():
    def __init__(self,ltms):
        self.root = None
        self.ltms = {} # 保存从address到ltm的映射
        # 建树
        seq = 0
        num = 2 * len(ltms) - 1
        for seq in range(1,num + 1):
            if seq == 2:
                self.add(seq,None,0,0,0)
            else:
                self.add(seq, None, 0, 0, 0)
        # 给ltm绑定address
        for i in range(len(ltms),2 * len(ltms)):
            ltms[i - len(ltms)].address = i
            self.ltms[i] = ltms[i - len(ltms)]
        # 检测树的结构
        self.travel()
        return

    def add(self,address,gist,weight,intensity,mood):
        if self.root is None:
            self.root = Trunk(address,gist,weight,intensity,mood)
        else:
            queue = []
            queue.append(self.root)
            while len(queue) > 0:
                node = queue.pop(0)
                if not node.LeftChild:
                    node.LeftChild = Trunk(address,gist,weight,intensity,mood)
                    return
                else:
                    queue.append(node.LeftChild)
                if not node.RightChild:
                    node.RightChild = Trunk(address,gist,weight,intensity,mood)
                    return
                else:
                    queue.append(node.RightChild)

    def uptree(self,tmp):
        if tmp.LeftChild and tmp.RightChild:
            self.up(tmp, tmp.LeftChild, tmp.RightChild)
            self.uptree(tmp.LeftChild)
            self.uptree(tmp.RightChild)
        else:
            tmp.address = self.ltms[tmp.address].address
            tmp.gist = self.ltms[tmp.address].feeling
            tmp.weight = gl.get_value(self.ltms[tmp.address].feeling)
            tmp.intensity = 10 - tmp.weight
            tmp.mood = tmp.weight
        return
    '''
    l,r是o的两个子节点，请根据l,r更新o中的chunk,假设l,r刚刚更新完毕
    '''
    def up(self,o,l,r):
        if l.weight >= r.weight:
            o.address, o.gist, o.weight, o.intensity, o.mood = l.address, l.gist, l.weight,\
                                                     l.intensity + r.intensity, \
                                                     l.mood + r.mood
        else:
            o.address, o.gist, o.weight, o.intensity, o.mood = r.address, r.gist, r.weight,\
                                                     l.intensity + r.intensity, \
                                                     l.mood + r.mood
        return

    def down(self):
        return

    def travel(self):
        if self.root is None:
            return
        queue = Queue()
        queue.put(self.root)
        while queue.qsize() > 0:
            node = queue.get()
            print(str(node.address))
            if node.LeftChild:
                queue.put(node.LeftChild)
                print(str(node.LeftChild.address))
            if node.RightChild:
                queue.put(node.RightChild)
                print(str(node.RightChild.address))
            print()

    def getLeaves(self):
        list = []
        if self.root is None:
            return list
        queue = []
        queue.append(self.root)
        while len(queue) > 0:
            node = queue.pop(0)
            if node.LeftChild:
                queue.append(node.LeftChild)
            if node.RightChild:
                queue.append(node.RightChild)
            if not node.LeftChild:
                list.append(node.address)
        return list

    # def update(self):
    #     if self.root is None:
    #         return
    #     queue = []
    #     queue.append(self.root)
    #     while len(queue) > 0:
    #         node = queue.pop(0)
    #         if node.LeftChild:
    #             queue.append(node.LeftChild)
    #             if node.LeftChild.weight >= node.RightChild.weight:
    #                 address,gist,weight,intensity,mood = node.LeftChild.address, node.LeftChild.gist, node.LeftChild.weight, node.LeftChild.intensity + node.RightChild.intensity, node.LeftChild.mood + node.RightChild.mood
    #             else:
    #                 address,gist,weight,intensity,mood = node.RightChild.address, node.RightChild.gist, node.RightChild.weight, node.LeftChild.intensity + node.RightChild.intensity, node.LeftChild.mood + node.RightChild.mood
    #             node.set(address,gist,weight,intensity,mood)
    #         if node.RightChild:
    #             queue.append(node.RightChild)

    def setLeaf(self,address,gist,weight,intensity,mood):
        if self.root is None:
            return list
        queue = []
        queue.append(self.root)
        while len(queue) > 0:
            node = queue.pop(0)
            if node.address == address:
                node.set(address,gist,weight,intensity,mood)
            if node.LeftChild:
                queue.append(node.LeftChild)
            if node.RightChild:
                queue.append(node.RightChild)