# import sys
# import os
# os.path.realpath(__file__)
# # file = open('../test.py','r')
# # file.close()
# # print(os.getcwd())
# # print( os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
# # print( os.path.abspath(os.path.dirname(os.getcwd())))
# # print( os.path.abspath(os.path.join(os.getcwd(), "..")))
# # os._exists()
# print(os.listdir('../../ex'))
# import globalvar as gl
# # gl._init()
# gl.set_value('name','zkx')
# print(1,gl.get_value('name'))
# file = open('test2.py','r')
# print(file.readlines())
# file.close()













'''
知识图谱交互对象
'''
global query
global update
query = SPARQLWrapper("http://localhost:3030/" + self.name + "/query")
update = SPARQLWrapper("http://localhost:3030/" + self.name + "/update")
query.setReturnFormat(JSON)
update.setMethod('POST')