# -*- coding: utf-8 -*-
"""
Created on Wed Aug 14 21:47:16 2019

@author: C-82
"""
'''
配置交互文件路径名
'''
agentControlPath = ''
environmentMessagePath = ''
shortTimeKnowledgePath = ''
longTimeKnowledgePath = ''
def configpath(name):
    agentControlPath = '../../externalsetting/' + name + '/interaction/agentControl.json'
    environmentMessagePath = '../../externalsetting/' + name + '/interaction/environmentMessage.json'
    shortTimeKnowledgePath = '../../externalsetting/' + name + '/interaction/shortTimeKnowledge.json'
    longTimeKnowledgePath = '../../externalsetting/' + name + '/interaction/longTimeKnowledge.json'
    return
'''
配置共享全局变量
'''
globalvars = {}
def set_value(name,value):
    globalvars[name] = value
    return
def get_value(name):
    try:
        return globalvars[name]
    except:
        return None