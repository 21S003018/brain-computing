# import numpy as np
# import pandas as pd
# df = pd.read_excel('data.xlsx')
# from matplotlib import pyplot as plt
# from matplotlib import animation
# # import numpy as np
# import seaborn as sns
# sns.set_style("whitegrid")
#
#
# # 创建画布，包含2个子图
# fig = plt.figure()
# ax = fig.add_subplot()
# x = [df.values[0][0], df.values[0][2], df.values[0][4], df.values[0][6]]
# y = [df.values[0][1], df.values[0][3], df.values[0][5], df.values[0][7]]
# sca = ax.scatter(x,y)
# def init():
#     label = 'timestep {0}'.format(0)
#     ax.set_xlabel(label)
#     return sca,ax
#
# def animate(i):
#     i = int(i)
#     a = [df.values[i][0],df.values[i][2],df.values[i][4], df.values[i][6]]
#     b = [df.values[i][1],df.values[i][3],df.values[i][5], df.values[i][7]]
#     # ax1.scatter(np.array(x),np.array(y))
#     sca.set_offsets([[x,y] for x,y in zip(a,b)])
#     label = 'timestep {0}'.format(i)
#     ax.set_xlabel(label)
#     return sca,ax
#
#
# # 接下来，我们调用FuncAnimation函数生成动画。参数说明：
# # fig 进行动画绘制的figure
# # func 自定义动画函数，即传入刚定义的函数animate
# # frames 动画长度，一次循环包含的帧数
# # init_func 自定义开始帧，即传入刚定义的函数init
# # interval 更新频率，以ms计
# # blit 选择更新所有点，还是仅更新产生变化的点。应选择True，但mac用户请选择False，否则无法显示动画
#
# ani = animation.FuncAnimation(fig=fig,
#                               func=animate,
#                               frames=80,
#                               init_func=init,
#                               interval=200,
#                               blit=False)
# plt.xlim([50,200])
# plt.ylim([50,200])
# plt.show()
# # ani.save(r'D:\demoanimation.gif', writer='imagemagick', fps=3)

import numpy as np
import pandas as pd
df = pd.read_excel('data.xlsx')
from matplotlib import pyplot as plt
from matplotlib import animation
# import numpy as np
import seaborn as sns
sns.set_style("whitegrid")


# 创建画布，包含2个子图
# fig = plt.figure()
# ax = fig.add_subplot()
height = 50
width = height / 23 * 62
fig,ax = plt.subplots(2,5,figsize=(200,1000))
plt.subplots_adjust(hspace=0.3, wspace=0.3)

agentx = [df.values[0][0]]
agenty = [df.values[0][1]]
preyx = [df.values[0][2]]
preyy = [df.values[0][3]]
predatorx= [df.values[0][4]]
predatory = [df.values[0][5]]
agentfx = [df.values[0][6]]
agentfy = [df.values[0][7]]

# sca1 = ax.scatter(agentx,agenty,label='agent')
# sca2 = ax.scatter(preyx,preyy,label='prey')
# sca3 = ax.scatter(predatorx,predatory,label='predator')
# sca4 = ax.scatter(agentfx,agentfy,label='agentf')
plt.legend()
# plt.show()

# def init():
#     label = 'timestep {0}'.format(0)
#     ax.set_xlabel(label)
#     return sca1,sca2,sca3,sca4,ax

def animate(i):
    i = int(i)
    agentx = df.values[i][0]
    agenty = df.values[i][1]
    preyx = df.values[i][2]
    preyy = df.values[i][3]
    predatorx = df.values[i][4]
    predatory = df.values[i][5]
    agentfx = df.values[i][6]
    agentfy = df.values[i][7]
    # ax1.scatter(np.array(x),np.array(y))
    # sca1.set_offsets([[x,y])
    sca1.set_offsets([agentx, agenty])
    sca2.set_offsets([preyx, preyy])
    sca3.set_offsets([predatorx, predatory])
    sca4.set_offsets([agentfx, agentfy])
    label = 'timestep {0}'.format(i)
    ax.set_xlabel(label)
    return sca1,sca2,sca3,sca4,ax


# 接下来，我们调用FuncAnimation函数生成动画。参数说明：
# fig 进行动画绘制的figure
# func 自定义动画函数，即传入刚定义的函数animate
# frames 动画长度，一次循环包含的帧数
# init_func 自定义开始帧，即传入刚定义的函数init
# interval 更新频率，以ms计
# blit 选择更新所有点，还是仅更新产生变化的点。应选择True，但mac用户请选择False，否则无法显示动画

# ani = animation.FuncAnimation(fig=fig,
#                               func=animate,
#                               frames=80,
#                               init_func=init,
#                               interval=200,
#                               blit=False)
# plt.xlim([50,150])
# plt.ylim([50,140])
# plt.show()
# ani.save(r'D:\exp2double.gif', writer='imagemagick', fps=3)
def savefig():
    step = int(len(df.values) / 10)
    for index in range(10):
        i = index * step
        agentx = df.values[i][0]
        anenty = df.values[i][1]
        preyx = df.values[i][2]
        preyy = df.values[i][3]
        predatorx = df.values[i][4]
        predatory = df.values[i][5]

        sca1 = ax[int(index/5)][index%5].scatter(agentx,anenty,label='Alice')
        sca2 = ax[int(index/5)][index%5].scatter(preyx,preyy,label='prey')
        sca3 = ax[int(index/5)][index%5].scatter(predatorx,predatory,label='predator')

        # sca1 = ax.scatter(agentx,agenty,label='agent')
        # sca2 = ax.scatter(preyx,preyy,label='prey')
        # sca3 = ax.scatter(predatorx,predatory,label='predator')
        sca4 = ax[int(index/5)][index%5].scatter(agentfx,agentfy,label='Bob')

        label = 'slot {0}'.format(i+1)
        ax[int(index/5)][index%5].set_xlabel(label)
        ax[int(index/5)][index%5].set_xlim([50,150])
        ax[int(index/5)][index%5].set_ylim([50,140])
        ax[int(index/5)][index%5].legend()
        # ax[int(index/5)][index%5].set_width(50)
        # ax[int(index/5)][index%5].set_height(50)
    # plt.savefig('fig/step{0}.png'.format(i))
    # plt.savefig('fig.png')
    plt.show()
    return
savefig()