import globalvar as gl
def func():
    print(gl.environmentMessagePath)
    return
import time
time.sleep(5)
func()