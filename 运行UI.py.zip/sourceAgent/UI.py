# -*- coding: utf-8 -*-
"""
Created on Wed Aug 14 20:01:38 2019

@author: C-82
"""
from builtin.agentFactory import AGENT

def produce(name):
    '''
    为一个角色初始化文件夹以及相关文件配置
    :param name: 角色名字
    :return: None
    '''
    return

def func1(name):
    '''
    开始运行一个agent
    :param name:
    :return:
    '''
    from multiprocessing import Process
    Process(target = AGENT,args = [name]).start()
if __name__ == "__main__":
    # func1('cbz')
    # func1('zsw')
    agent = AGENT('cbz')