import globalvar as gl
def func():
    print(gl.name)
    return