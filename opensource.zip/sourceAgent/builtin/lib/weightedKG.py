# -*- coding: utf-8 -*-
"""
Created on Mon Sep 23 16:46:16 2019

@author: 陈泊舟
"""
from SPARQLWrapper import SPARQLWrapper, JSON
import os
# os.system("@echo off")
# os.system("java -Xmx1200M -jar fuseki-server.jar")
'''
vertex class
inherit object class
describe a vertex in the graph
'''
class vertex(object):
    '''
    constructor
    three parameters:factor1，factor2，label
    when you call this method, the value of label should be cleared.
    and a tip is that if you want use the graph in some way, the meaning of factors should be determined by yourself.
    '''
    def __init__(self,label,factor1 = 0,factor2 = 0):
        self.__factor1 = factor1
        self.__factor2 = factor2
        self.__label = label
        return
    '''
    we think two vertex objects are the same if they have the same label
    '''
    def __eq__(self,that):
        if self.__label == that.getLabel():
            return True
        return False
    '''
    set and observe methods
    you can change all the value of those attributes apart from label
    '''
    def setFactor1(self,value):
        self.__factor1 = value
        return
    def setFactor2(self,value):
        self.__factor2 = value
        return
    def getFactor1(self):
        return self.__factor1
    def getFactor2(self):
        return self.__factor2
    def getLabel(self):
        return self.__label

'''
edge class
inherit object class
describe an edge in the graph
'''
class edge(object):
    '''
    constructor
    four parameters:start and target are the starting vertex and the end vertex of the edge
    weight is the weight of edge you give to the edge
    relation describe the the relation between the two vertices
    when you construct an object of edge, you must clear the value of start,target
    '''
    def __init__(self,start,target,weight = 0,relation = 'general'):
        self.__start = start
        self.__target = target
        self.__weight = weight
        self.__relation = relation
        return
    '''
    we think two edge are the same iff the starting vertex,end vertex and the relation are the same in the same time
    '''
    def __eq__(self,that):
        if self.__start != that.getStart():
            return False
        if self.__target != that.getTarget():
            return False
        if self.__relation != that.getRelation():
            return False
        return True
    '''
    set and observe methods
    only the value of weight and relation can be changed
    '''
    def setWeight(self,value):
        self.__weight = value
        return
    def setRelation(self,value):
        self.__relation = value
        return
    def getStart(self):
        return self.__start
    def getTarget(self):
        return self.__target
    def getWeight(self):
        return self.__weight
    def getRelation(self):
        return self.__relation

'''
graph class
inherit object class
describe a graph which can be used like a knowledge graph but also a 
'''
class KnowldgeGraph(object):
    '''
    constructor
    use an indegree adjacency table and a outdegree adjacency table store the graph
    use two object __query and __update to operate the knowledge graph
    parameter:name is an object used to specify different graphs
    '''
    def __init__(self,name):
        self.name = name
        self.__ingraph = {}
        self.__outgraph = {}
        self.__update = SPARQLWrapper("http://localhost:3030/" + self.name + "/update")
        self.__query = SPARQLWrapper("http://localhost:3030/" + self.name + "/query")
        self.__query.setReturnFormat(JSON)
        self.__update.setMethod('POST')
        return
    '''
    addEdge method
    add an edge to the graph,including the relation between two vertices in kg
    and entity in the normal graph
    and that the type of all the parameters are string
    one point is that it's right to say o1 has r relation with o2,but it's not right to say o2 has r relation with o1
    '''
    def addEdge(self,o1,r,o2):
        '''
        change the knowledge graph
        '''
        self.__update.setQuery(
        "PREFIX rdf:   <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
        +"PREFIX ex:   <http://example.org/>"
        
        +"INSERT DATA {"
        +"ex:" + o1 + "        rdf:" + r + "             ex:" + o2 + "     ."
        +"}")
        self.__update.query()
        '''
        change the normal graph
        '''
        vertex1 = vertex(label = o1)
        vertex2 = vertex(label = o2)
        _edge = edge(start = vertex1,target = vertex2,relation = r)
        '''
        deal with the indegree graph
        '''
        if self.__ingraph.__contains__(vertex2.getLabel()):
            self.__ingraph[vertex2.getLabel()].append(_edge)
        else:
            self.__ingraph[vertex2.getLabel()] = [_edge]
        '''
        deal with the outdegree graph
        '''
        if self.__outgraph.__contains__(vertex1.getLabel()):
            self.__outgraph[vertex1.getLabel()].append(_edge)
        else:
            self.__outgraph[vertex1.getLabel()] = [_edge]
        return
    '''
    removeEdge method
    remove the edge from the double graphs,but leave the entity in the graph
    '''
    def removeEdge(self,o1,r,o2):
        '''
        change the knowledge graph
        '''
        self.__update.setQuery(
        "PREFIX rdf:   <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
        +"PREFIX ex:   <http://example.org/>"
        
        +"DELETE DATA {"
        +"ex:" + o1 + "        rdf:" + r + "             ex:" + o2 + "     .}")
        self.__update.query()
        '''
        change the normal graph
        '''
        vertex1 = vertex(label = o1)
        vertex2 = vertex(label = o2)
        '''
        deal with the indegree graph
        '''
        if self.__ingraph.__contains__(vertex2.getLabel()) == True:
            for tmp_edge in self.__ingraph[vertex2.getLabel()]:
                if tmp_edge.getStart() == vertex1:
                    self.__ingraph[vertex2.getLabel()].remove(tmp_edge)
                    break
        '''
        deal with the outdegree graph
        '''
        if self.__outgraph.__contains__(vertex1.getLabel()) == True:
            for tmp_edge in self.__outgraph[vertex1.getLabel()]:
                if tmp_edge.getTarget() == vertex2:
                    self.__outgraph[vertex1.getLabel()].remove(tmp_edge)
                    break
        return
    '''
    query method family
    you will get the relations between the two objects
    maybe not just one,so the return type is a list
    '''
    def queryRelation(self,o1,o2):
        self.__query.setQuery("PREFIX rdf:   <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
        +"PREFIX ex:   <http://example.org/>"
        
        +"SELECT * WHERE {"
        +"ex:" + o1 + "        ?ans             ex:" + o2 + "     ."
        +"}")
        ans = self.__query.query().convert()['results']['bindings']
        ret = []
        for x in ans:
            ret.append(x['ans']['value'].replace('http://www.w3.org/1999/02/22-rdf-syntax-ns#',''))
        return ret
    '''
    query method family
    you will get the entity that o1 has relation with
    '''
    def queryO2(self,o1,r):
        self.__query.setQuery("PREFIX rdf:   <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
        +"PREFIX ex:   <http://example.org/>"
        
        +"SELECT * WHERE {"
        +"ex:" + o1 + "        rdf:" + r + "             ?ans     ."
        +"}")
        ans = self.__query.query().convert()['results']['bindings'][0]['ans']['value'].replace('http://example.org/','')
        return ans
    '''
    query method family
    you will get the entity o1 which has relation with o2
    '''
    def queryO1(self,r,o2):
        self.__query.setQuery("PREFIX rdf:   <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
        +"PREFIX ex:   <http://example.org/>"
        
        +"SELECT * WHERE {"
        +"?ans        rdf:" + r + "             ex:" + o2 + "     ."
        +"}")
        ans = self.__query.query().convert()['results']['bindings'][0]['ans']['value'].replace('http://example.org/','')
        return ans
    '''
    query method to solve the need
    '''
    def querymethod(self,need):
        return
    '''
    setFactor1 method
    '''
    def setFactor1(self,o,x):
        for vertex in self.__ingraph:
            if vertex == o:
                vertex.setFactor1(x)
        for vertex in self.__outgraph:
            if vertex == o:
                vertex.setFactor1(x)
        return
    '''
    setFactor2 method
    '''
    def setFactor2(self,o,x):
        for vertex in self.__ingraph:
            if vertex == o:
                vertex.setFactor2(x)
        for vertex in self.__outgraph:
            if vertex == o:
                vertex.setFactor2(x)
        return
    '''
    setWeight method
    '''
    def setWeight(self,o1,r,o2,x):
        for tmp_edge in self.__ingraph:
            if tmp_edge.getStart().getLabel() == o1:
                tmp_edge.setWeight(x)
                break
        for tmp_edge in self.__outgraph:
            if tmp_edge.getTarget().getLabel() == o2:
                tmp_edge.setWeight(x)
                break
        return
    '''
    calReward method
    used to calculate the reward of the method,
    which is prepared to solve the tmp need
    '''
    def calReward(self,method):
        return 1



'''
参考信息
'''
#
# """
# self.__ingraph
# 入度邻接表
# """
# self.__ingraph = {}
# """
# self.__outgrpah
# 出度邻接表
# """
# self.__outgraph = {}
# """
# self.__intensity
# 记录各个需求强度（reward）
# """
# self.__intensity = {}
# """
# self.__factors
# 记录所有概念在此决策中的参与程度
# """
# self.__factors = []
# """
# 建立原始图
# """
# self.addEdge("unhungry", "happy", 1)
# self.addEdge("unthirsty", "happy", 1)
# self.addEdge("unpain", "happy", 1)
# self.addEdge("unsleepy", "happy", 1)
# self.addEdge("sexy", "happy", 1)
# self.addEdge("catchfish", "unhungry", 2)
# self.addEdge("pick", "unhungry", 1)
# self.addEdge("eat", "unhungry", 2)
# self.addEdge("collectRainwater", "unthirsty", 2)
# self.addEdge("fetchWater", "unthirsty", 1)
# self.addEdge("drink", "unthirsty", 2)
# self.addEdge("sleep", "unsleepy", 2)
#
#
#
#     """
# #    getNeedIntensity方法
# #    根据自身的状态返回需求强度
# #    返回值是一个元组
#     """
#
#     def getNeedIntensity(self):
#         needOfSleepy = 10 / gl.get_value(self.feeling)
#         return (self.feeling, needOfSleepy)
#
#     """
# #    add_Edge方法
# #    添加一个关系
#     """
#
#     def addEdge(self, s, t, weight):
#         '''
#         处理需求序列
#         '''
#         if self.__intensity.__contains__(s) == False:
#             self.__intensity[s] = 0
#         if self.__intensity.__contains__(t) == False:
#             self.__intensity[t] = 0
#         '''
#         处理in图
#         '''
#         tmp_tuple = (s, weight)
#         if self.__ingraph.__contains__(t):
#             self.__ingraph[t].append(tmp_tuple)
#         else:
#             self.__ingraph[t] = [tmp_tuple]
#         '''
#         处理out图
#         '''
#         tmp_tuple = (t, weight)
#         if self.__outgraph.__contains__(s):
#             self.__outgraph[s].append(tmp_tuple)
#         else:
#             self.__outgraph[s] = [tmp_tuple]
#         return
#
#     """
# #    removeEdge方法
# #    删除一个关系
#     """
#
#     def removeEdge(self, s, t):
#         '''
#         处理需求序列
#         '''
#         if self.__intensity.__contains__(s):
#             self.__intensity.pop(s)
#         if self.__intensity.__contains__(t):
#             self.__intensity.pop(t)
#         '''
#         处理in图
#         '''
#         if self.__ingraph.__contains__(t) == True:
#             for tmp_vertex in self.__ingraph[t]:
#                 if tmp_vertex[0] == s:
#                     self.__ingraph[t].remove(tmp_vertex)
#                     break
#         '''
#         处理out图
#         '''
#         if self.__outgraph.__contains__(s) == True:
#             for tmp_vertex in self.__outgraph[s]:
#                 if tmp_vertex[0] == t:
#                     self.__outgraph[s].remove(tmp_vertex)
#                     break
#         return
#
#     """
# #    updateWeight方法
# #    更新某两个结点之间的权重
#     """
#
#     def updateWeight(self, s, t, weight):
#         if self.__ingraph.__contains__(t):
#             for tmp_vertex in self.__ingraph[t]:
#                 if tmp_vertex[0] == s:
#                     self.__ingraph[t].remove(tmp_vertex)
#                     tmp_vertex[1] = weight
#                     self.__ingraph[t].append(tmp_vertex)
#                     break
#         if self.__outgraph.__contains__(s):
#             for tmp_vertex in self.__outgraph[s]:
#                 if tmp_vertex[0] == t:
#                     self.__outgraph[s].remove(tmp_vertex)
#                     tmp_vertex[1] = weight
#                     self.__outgraph[s].append(tmp_vertex)
#                     break
#         return
#
#     """
# #    updateIntensity方法
# #    更新某一个结点的强度
#     """
#
#     def updateIntensity(self, vertex, intensity):
#         if self.__intensity.__contains__(vertex):
#             self.__intensity[vertex] = intensity
#             return
#         return
#
#     """
# #    calReward方法
# #    计算到达某一个点可以获得的reward
# #    一般用于happy
#     """
#
#     def calReward(self, vertex):
#         if self.__ingraph.__contains__(vertex) == False:
#             return self.__intensity[vertex]
#         ans = 1
#         for tmp_vertex in self.__ingraph[vertex]:
#             if self.__factors.__contains__(tmp_vertex) == False:
#                 continue
#             ans = ans + self.calReward(tmp_vertex) * self.__intensity[tmp_vertex] * self.__factors[tmp_vertex]
#         return ans
#
#     """
# #    setFactors方法
# #    设置每一个概念的参与度
# #    概念x科大的每一个概念都认为是参与的
# #    否则认为是不参与
#     """
#
#     def setFactors(self, targetFactors):
#         self.__factors = []
#         vis = {}
#         from queue import Queue
#         q = Queue()
#         q.put(targetFactors)
#         while q.empty() == False:
#             tmp = q.get()
#             self.__factors.append(tmp)
#             if self.__outgraph.__contains__(tmp) == True:
#                 for x in self.__outgraph[tmp]:
#                     if vis.__contains__(x[0]) == False:
#                         q.put(x[0])
#                         vis[x[0]] = 1
#         return
#
#     """
# #    getMethodsFromOrgan(organ)方法
# #    适配模式，参数换为organ
#     """
#
#     def getMethodsFromOrgan(self, organ):
#         query.setQuery(
#             "PREFIX rdf:   <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
#             + "PREFIX ex:   <http://example.org/>"
#
#             + "SELECT * WHERE {"
#             + "ex:" + organ + "        rdf:feeling             ?ans     ."
#             + "}")
#         need = query.query().convert()['results']['bindings'][0]['ans']['value'].replace('http://example.org/', '')
#         return self.getMethodsFromNeed(need)
#
#     """
# #    getMethodsFromNeed(need)方法
# #    在知识图谱中查找
#     """
#
#     def getMethodsFromNeed(self, need):
#         query.setQuery(
#             "PREFIX rdf:   <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
#             + "PREFIX ex:   <http://example.org/>"
#
#             + "SELECT * WHERE {"
#             + "ex:" + need + "        rdf:use             ?ans     ."
#             + "}")
#         ans = query.query().convert()['results']['bindings']
#         ret = []
#         for x in ans:
#             ret.append(x['ans']['value'].replace('http://example.org/', ''))
#         return ret
