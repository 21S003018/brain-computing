import globalvar as gl
# # gl._init()
# # gl.set_value('name','cbz')
# import time
# time.sleep(7)
# print(gl.get_value('name'))
def func():
    gl.name = 'zkx'
    return