import time
import os
from globalvar import *
import globalvar as gl

import json


def sleep(params):
    """
    tired值低于某一阈值的时触发，状态值会有所增加
    :return:None
    """
    def content():
        gl.set_value('signal_sleep',1)
        # 输出开始控制命令
        dic = {}
        dic['operation'] = 'sleep'
        dic = json.dumps(dic)
        file = open(gl.get_value('agentControlPath'), "w")
        file.write(str(dic))
        file.close()
        # 等待agent信号
        rate = 0.5
        while(gl.get_value('signal_sleep') == 1):
            gl.set_value('tired', gl.get_value('tired') + rate)
            time.sleep(1)
        # 输出结束控制命令
        dic = {}
        dic['command'] = 'sleep over'
        file = open(gl.get_value('agentControlPath'), "w")
        file.write(str(json.dumps(dic)))
        file.close()
        return
    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


def move(params):
    # 设置参数
    theta = params['theta']
    phi = params['phi']
    speed = None
    try:
        speed = params['speed']
    except:
        speed = 1
    """
    移动
    :param theta: 球坐标-[0,2pi]
    :param phi: 球坐标[0,pi]
    :param speed: number
    :return:
    """
    def content():
        gl.set_value('signal_move',1)
        """
        向环境传递移动信息
        """
        dic = {}
        dic = {"operation": "move", "param1": theta, "param2": phi,"param3": speed}
        import json
        dic = json.dumps(dic)
        file = open(gl.get_value('agentControlPath'), "w")
        file.write(str(dic))
        file.close()
        while gl.get_value('signal_move') == 1:
            time.sleep(1)
        dic = {}
        dic['command'] = 'move over'
        file = open(gl.get_value('agentControlPath'), "w")
        file.write(str(json.dumps(dic)))
        file.close()
        return
    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


def observe(target,angle):
    """
    传递观察命令
    正常情况下agent一直在进行视觉的信息提取
    但是在执行观察命令之后agent会获得更多的视觉信息
    """
    gl.set_value('signal_observe', 1)
    gl.set_value('observe_target',target)
    gl.set_value('observe_target_pos',None)
    dic = {"operation": "observe","param1": angle}
    import json
    dic = json.dumps(dic)
    file = open(gl.get_value('agentControlPath'), "w")
    file.write(str(dic))
    file.close()
    timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
    while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
        import time
        time.sleep(1)
    '''检索视觉信息,发现target'''
    while gl.get_value('signal_observer') == 1:
        angle = angle + 60
        file = open(gl.get_value('agentControlPath'), "w")
        dic = {}
        dic[1] = {"operation": "observe", "param1": angle}
        import json
        dic = json.dumps(dic)
        file.write(str(dic))
        file.close()
    file = open(gl.get_value('agentControlPath'), "w")
    dic = {}
    dic['command'] = 'observe over'
    file.write(str(json.dumps(dic)))
    file.close()
    return gl.get_value('observe_target_pos')

def observe(target):
    """
    传递观察命令
    正常情况下agent一直在进行视觉的信息提取
    但是在执行观察命令之后agent会获得更多的视觉信息
    """
    file = open(gl.get_value('agentControlPath'), "w")
    dic = {}
    dic[1] = {"operation": "observe"}
    import json
    dic = json.dumps(dic)
    file.write(str(dic))
    file.close()
    timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
    while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
        import time
        time.sleep(1)
    '''检索视觉信息,发现target'''
    file = open(gl.get_value('environmentMessagePath'), 'r')
    import json
    visionMessage = json.load(file)['vision']
    file.close()
    for i in range(1, 100000):
        if visionMessage.__contains__(i):
            message = visionMessage[i]
            if message['object'] == target:
                return message['pos']
        else:
            break
    return None


"""
TODO
定位
寻找流程
"""


def catchfish():
    def content():
        print(gl.get_value('name') + " is going to catche fish")
        '''找鱼叉(在寻找鱼叉的过程中move的方向需要单独进行考虑)'''
        import random
        dx = random.randint(-2, 2)
        dy = random.randint(-2, 2)
        dz = random.randint(-2, 2)
        move(dx, dy, dz)
        ans = observe('fish spear')
        while ans == None:
            ans = observe('fish spear')
        dx = ans[0]
        dy = ans[1]
        dz = ans[2]
        move(dx, dy, dz)
        '''拾起鱼叉'''
        pick('fish spear')
        '''找鱼塘'''
        import random
        dx = random.randint(-2, 2)
        dy = random.randint(-2, 2)
        dz = random.randint(-2, 2)
        move(dx, dy, dz)
        ans = observe('fish pond')
        while ans == None:
            ans = observe('fish pond')
        dx = ans[0]
        dy = ans[1]
        dz = ans[2]
        move(dx, dy, dz)
        '''投掷鱼叉'''
        import json
        file = open(gl.get_value('agentControlPath'), "w")
        dic = {}
        dic[1] = {"operation": "catchfish"}
        dic = json.dumps(dic)
        file.write(str(dic))
        file.close()
        import os
        timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
        while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
            import time
            time.sleep(1)
            return

    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


'''
TODO
'''


def pick(target):
    def content():
        """
        向环境传递移动信息
        """
        print(gl.get_value('name') + " is going to pick " + target)

        file = open(gl.get_value('agentControlPath'), "w")
        dic = {}
        dic[1] = {"operation": "pick", "param1": target}

        import json
        dic = json.dumps(dic)
        file.write(str(dic))
        file.close()

        timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
        while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
            import time
            time.sleep(1)
        print("pick succeed!")
        return

    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


"""
completed
"""


def eat(food_type, speed):

    def content():
        print(gl.get_value('name') + " is going to eat!")
        """
        向环境传递睡觉信息
        """
        dic = {}
        dic[1] = {"operation": "eat", "param1": food_type, "param2": speed}
        import json
        dic = json.dumps(dic)
        file = open(gl.get_value('agentControlPath'), "w")
        file.write(str(dic))
        file.close()
        timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
        while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
            print('st_mtime')
            print(os.stat(gl.get_value('agentControlPath')).st_mtime)
            import time
            time.sleep(1)
        gl.set_value('stomach', gl.get_value('stomach') + 5)
        return

    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


"""
TODO
流程
"""


def collect_rainwater(tool):
    '''找工具'''
    print(gl.get_value('name') + "is going to collect water with " + tool)

    def content():
        import random
        dx = random.randint(-2, 2)
        dy = random.randint(-2, 2)
        dz = random.randint(-2, 2)
        move(dx, dy, dz)
        ans = observe(tool)
        while ans == None:
            ans = observe(tool)
        dx = ans[0]
        dy = ans[1]
        dz = ans[2]
        move(dx, dy, dz)
        '''拿起工具'''
        pick(tool)
        '''找下雨的地方'''
        import random
        dx = random.randint(-2, 2)
        dy = random.randint(-2, 2)
        dz = random.randint(-2, 2)
        move(dx, dy, dz)
        ans = observe('rain')
        while ans == None:
            ans = observe('rain')
        dx = ans[0]
        dy = ans[1]
        dz = ans[2]
        move(dx, dy, dz)
        '''在下雨的地方放置工具'''
        """
        向环境传递移动信息
        """
        file = open(gl.get_value('agentControlPath'), "w")
        dic = {}
        dic[1] = {"operation": "collect_rainwater", "param1": tool, "param2": dx, "param3": dy, "param4": dz}
        import json
        dic = json.dumps(dic)
        file.write(str(dic))
        file.close()
        timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
        while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
            import time
            time.sleep(1)
        return

    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


"""
TODO
流程
"""


def fetch_water(tool):
    '''找工具'''
    print(gl.get_value('name') + "is going to fetch water with " + tool)

    def content():
        import random
        dx = random.randint(-2, 2)
        dy = random.randint(-2, 2)
        dz = random.randint(-2, 2)
        move(dx, dy, dz)
        ans = observe(tool)
        while ans == None:
            ans = observe(tool)
        dx = ans[0]
        dy = ans[1]
        dz = ans[2]
        move(dx, dy, dz)
        '''拿起工具'''
        pick(tool)
        '''找水源'''
        import random
        dx = random.randint(-2, 2)
        dy = random.randint(-2, 2)
        dz = random.randint(-2, 2)
        move(dx, dy, dz)
        ans = observe('water')
        while ans == None:
            ans = observe('water')
        dx = ans[0]
        dy = ans[1]
        dz = ans[2]
        move(dx, dy, dz)
        '''用工具盛水'''
        """
        向环境传递移动信息
        """
        file = open(gl.get_value('agentControlPath'), "w")
        dic = {}
        dic[1] = {"operation": "fetch_water", "param1": tool, "param2": dx, "param3": dy, "param4": dz}
        import json
        dic = json.dumps(dic)
        file.write(str(dic))
        file.close()
        timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
        while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
            import time
            time.sleep(1)
        return

    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


"""
completed
"""


def drink(drink_type, speed):

    def content():
        print(gl.get_value('name') + " is going to drink!")
        """
        向环境传递睡觉信息
        """
        dic = {}
        dic[1] = {"operation": "eat", "param1": drink_type, "param2": speed}
        import json
        dic = json.dumps(dic)
        file = open(gl.get_value('agentControlPath'), "w")
        file.write(str(dic))
        file.close()
        timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
        while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
            print('st_mtime')
            print(os.stat(gl.get_value('agentControlPath')).st_mtime)
            import time
            time.sleep(1)
        gl.set_value('oralCavity', gl.get_value('oralCavity') + 5)
        return

    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


"""
TODO
"""


def defense(tool, target_x, target_y, target_z):
    def content():
        """
        防御
        """
        print(gl.get_value('name') + "is going to defense!")
        file = open(gl.get_value('agentControlPath'), "w")
        dic = {}
        dic[1] = {"operation": "defense", "param1": target_x, "param2": target_y, "param3": target_z}
        import json
        dic = json.dumps(dic)
        file.write(str(dic))
        file.close()
        timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
        while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
            import time
            time.sleep(1)
        return

    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


"""
TODO
攻击检测
演示结合
"""
def attack(tool, target_x, target_y, target_z):
    def content():
        """
        函数开始提示信息
        """
        print(gl.get_value('name') + " take attacking!")
        """
        向环境传递控制信息
        """
        dic = {}
        dic[1] = {"operation": "attack", "param1": tool, "param2": target_x, "param3": target_y, "param4": target_z}
        import json
        dic = json.dumps(dic)
        file = open(gl.get_value('agentControlPath'), "w")
        file.write(str(dic))
        file.close()
        timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
        """
        等待环境执行结束
        """
        while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
            print('st_mtime')
            print(os.stat(gl.get_value('agentControlPath')).st_mtime)
            import time
            time.sleep(1)
        """
        TODO
        功能区
        """
        print("over!")
        return

    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


"""
TODO
函数存在的意义有待商榷
演示简单
位置信息的定位需要进行确定
"""


def give_up(target_x, target_y, target_z):
    def content():
        """
        函数开始提示信息
        """
        print(gl.get_value('name') + " give up!")
        """
        向环境传递控制信息
        """
        dic = {}
        dic[1] = {"operation": "give_up", "param1": target_x, "param2": target_y, "param3": target_z}
        import json
        dic = json.dumps(dic)
        file = open(gl.get_value('agentControlPath'), "w")
        file.write(str(dic))
        file.close()
        timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
        """
        等待环境执行结束
        """
        while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
            print('st_mtime')
            print(os.stat(gl.get_value('agentControlPath')).st_mtime)
            import time
            time.sleep(1)
        """
        TODO
        功能区
        """
        print("over!")
        return

    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


"""
TODO
另外起一个线程进行处理
需要获取对意识和知识的控制权
"""


def chat(target):
    def content():
        """
        函数开始提示信息
        """
        print(gl.get_value('name') + " is trying to chat " + str(target))
        """
        向环境传递控制信息
        """
        dic = {}
        dic[1] = {"operation": "chat", "param1": target}
        import json
        dic = json.dumps(dic)
        file = open(gl.get_value('agentControlPath'), "w")
        file.write(str(dic))
        file.close()
        timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
        """
        等待环境执行结束
        """
        while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
            print('st_mtime')
            print(os.stat(gl.get_value('agentControlPath')).st_mtime)
            import time
            time.sleep(1)
        """
        TODO
        功能区
        """
        print("Good bye!")
        return

    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


"""
TODO
具体实现流程
函数的实际意义
函数的实现效果
"""


def care(target):
    def content():
        """
        函数开始提示信息
        """
        print(gl.get_value('name') + " is trying to care " + str(target))
        """
        向环境传递控制信息
        """
        dic = {}
        dic[1] = {"operation": "care", "param1": target}
        import json
        dic = json.dumps(dic)
        file = open(gl.get_value('agentControlPath'), "w")
        file.write(str(dic))
        file.close()
        timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
        """
        等待环境执行结束
        """
        while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
            print('st_mtime')
            print(os.stat(gl.get_value('agentControlPath')).st_mtime)
            import time
            time.sleep(1)
        """
        TODO
        功能区
        """
        print("Yeap!")
        return

    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


"""
TODO
涉及语言的输出、知识图谱的更改以及结果的判断
"""


def make_new_friends(target):
    def content():
        """
        函数开始提示信息
        """
        print(gl.get_value('name') + " is trying to make friends with " + str(target))
        """
        向环境传递控制信息
        """
        dic = {}
        dic[1] = {"operation": "mnf", "param1": target}
        import json
        dic = json.dumps(dic)
        file = open(gl.get_value('agentControlPath'), "w")
        file.write(str(dic))
        file.close()
        timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
        """
        等待环境执行结束
        """
        while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
            print('st_mtime')
            print(os.stat(gl.get_value('agentControlPath')).st_mtime)
            import time
            time.sleep(1)
        """
        TODO
        功能区
        """
        print("Yeap!")
        return

    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


"""
TODO
需要调用语言处理机制
发送控制命令，向某人发送请求，请求某物
详细解释请见协议
"""


def func1(target, agent):
    def content():
        """
        函数开始提示信息
        """
        print(gl.get_value('name') + " is trying to get something from " + str(agent))
        """
        向环境传递控制信息
        """
        dic = {}
        dic[1] = {"operation": "func1", "param1": target, "param2": agent}
        import json
        dic = json.dumps(dic)
        file = open(gl.get_value('agentControlPath'), "w")
        file.write(str(dic))
        file.close()
        timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
        """
        等待环境执行结束
        """
        while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
            print('st_mtime')
            print(os.stat(gl.get_value('agentControlPath')).st_mtime)
            import time
            time.sleep(1)
        """
        TODO
        功能区
        """
        print("Thank you!")
        return

    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return


'''
TODO
具体思考并进行讨论实现
需要传递哪些控制命令
需要对自己的状态进行哪些更改
与别人合作某件事情
'''


def func2(target, agent):
    def content():
        """
        函数开始提示信息
        """
        print(gl.get_value('name') + " is trying to cooperate with " + str(agent))
        """
        向环境传递控制信息
        """
        dic = {}
        dic[1] = {"operation": "func2", "param1": target, "param2": agent}
        import json
        dic = json.dumps(dic)
        file = open(gl.get_value('agentControlPath'), "w")
        file.write(str(dic))
        file.close()
        timeStamp = os.stat(gl.get_value('agentControlPath')).st_mtime
        """
        等待环境执行结束
        """
        while timeStamp == os.stat(gl.get_value('agentControlPath')).st_mtime:
            print('st_mtime')
            print(os.stat(gl.get_value('agentControlPath')).st_mtime)
            import time
            time.sleep(1)
        """
        功能区
        """
        print("happy to cooperate!")
        return

    from threading import Thread
    problem_detect_thread = Thread(target=content)
    problem_detect_thread.setDaemon(True)
    problem_detect_thread.start()
    return
