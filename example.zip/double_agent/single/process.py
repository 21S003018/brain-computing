import numpy as np
import pandas as pd
df = pd.read_excel('data.xlsx')
from matplotlib import pyplot as plt
from matplotlib import animation
# import numpy as np
import seaborn as sns
sns.set_style("whitegrid")


# 创建画布，包含2个子图
fig = plt.figure()
ax = fig.add_subplot()
agentx = [df.values[0][0]]
anenty = [df.values[0][1]]
preyx = [df.values[0][2]]
preyy = [df.values[0][3]]
predatorx= [df.values[0][4]]
predatory = [df.values[0][5]]
sca1 = ax.scatter(agentx,anenty,label='agent')
sca2 = ax.scatter(preyx,preyy,label='prey')
sca3 = ax.scatter(predatorx,predatory,label='predator')
plt.legend()
# plt.show()

def init():
    label = 'timestep {0}'.format(0)
    ax.set_xlabel(label)
    return sca1,sca2,sca3,ax

def animate(i):
    i = int(i)
    agentx = df.values[i][0]
    anenty = df.values[i][1]
    preyx = df.values[i][2]
    preyy = df.values[i][3]
    predatorx = df.values[i][4]
    predatory = df.values[i][5]
    # ax1.scatter(np.array(x),np.array(y))
    # sca1.set_offsets([[x,y])
    sca1.set_offsets([agentx, anenty])
    sca2.set_offsets([preyx, preyy])
    sca3.set_offsets([predatorx, predatory])
    label = 'timestep {0}'.format(i)
    ax.set_xlabel(label)
    return sca1,sca2,sca3,ax


# 接下来，我们调用FuncAnimation函数生成动画。参数说明：
# fig 进行动画绘制的figure
# func 自定义动画函数，即传入刚定义的函数animate
# frames 动画长度，一次循环包含的帧数
# init_func 自定义开始帧，即传入刚定义的函数init
# interval 更新频率，以ms计
# blit 选择更新所有点，还是仅更新产生变化的点。应选择True，但mac用户请选择False，否则无法显示动画

ani = animation.FuncAnimation(fig=fig,
                              func=animate,
                              frames=64,
                              init_func=init,
                              interval=400,
                              blit=False)
plt.xlim([50,150])
plt.ylim([50,140])
# plt.show()
ani.save(r'D:\exp2single.gif', writer='imagemagick', fps=3)